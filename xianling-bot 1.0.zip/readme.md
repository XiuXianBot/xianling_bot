# koishi-plugin-xianling-bot

[![npm](https://img.shields.io/npm/v/koishi-plugin-xianling-bot?style=flat-square)](https://www.npmjs.com/package/koishi-plugin-xianling-bot)

私用
